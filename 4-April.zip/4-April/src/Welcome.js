function Welcome(props){
    return <div>
        <h1>Hello, Welcome TO React Application!!!!</h1>
        <h3>Hi, {props.fname} {props.lname}</h3>
    </div>
}

export default Welcome;