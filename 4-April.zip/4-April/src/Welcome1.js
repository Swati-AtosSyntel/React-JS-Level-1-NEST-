import React,{Component} from 'react';
class Welcome1 extends React.Component{
render(){
    return <div>
    <h1>Hello, Welcome TO React Application!!!!</h1>
    <h3>Hi, {this.props.fname} {this.props.lname}</h3>
</div>
}
}
Welcome1.defaultProps={
    fname:"React"
}
export default Welcome1;