import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import Welcome1 from './Welcome1';
import App2 from './App2';
import Employee from './Employee';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
       <Employee/>
        <App2/>
        <Welcome fname="Swati" lname="Bhirud"/>
        <Welcome1 fname="Ashwin" lname="Patil"/>
        <Welcome1 />
      </header>
    </div>
  );
}

export default App;
