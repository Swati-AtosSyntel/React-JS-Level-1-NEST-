import React,{Component} from 'react';
class Reservation extends React.Component{
    constructor(props){
        super(props);
        this.state={
            isGoing:true,
            numberofGuests:2
        };
this.handleInputChange=this.handleInputChange.bind(this);
this.handleSubmit=this.handleSubmit.bind(this);
}

    
handleInputChange(event){
    const target=event.target;
    const value=target.type==='checkbox'?target.checked:target.value;
    const [name,value1]=target;
    alert(name);
    this.setState({
        [name]:value1
    });
    // this.setState({
    //     [event.target.name]:event.target.value
    // });
   // event.preventDefault();
}
handleSubmit(event){
    event.preventDefault();
    alert('submitted data'+this.state.isGoing+this.state.numberofGuests);

}
    render(){
        return(
            <form onSubmit={this.handleSubmit}>
                <label>Is Going:</label> <input name="isGoing" type="checkbox" checked={this.state.isGoing}
                onChange={this.handleInputChange}/>
                <label>Number OF Guests: </label><input name="numberOfGuests" type="number"
                value={this.state.numberofGuests}
                onChange={this.handleInputChange}/>
                  <input type="Submit" value="submit"/>
                            </form>
        )
    }
}
export default Reservation;