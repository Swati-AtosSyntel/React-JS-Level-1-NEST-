function UserLogin(props){
    return <h4>Welcome User!!!</h4>
}
function GuestLogin(props){
    return <h4>Welcome GuestUser!!!....To go further please sign up</h4>
}

function SignUp(props){
    const isLoggedIn=props.isLoggedIn;
    if(isLoggedIn)
    return <UserLogin/>
    return <GuestLogin/>
}
export default SignUp;