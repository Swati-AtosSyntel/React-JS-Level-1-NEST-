import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import Welcome1 from './Welcome1';
import App2 from './App2';
import Employee from './Employee';
import App3 from './App3';
import SignUp from './SignUp';
import CountApp from './HooksEx';
import App4 from './useState';
import App5 from './useEffect';
import UCform from './uncontrolledform';
import Cform from './controlledForm';
import Reservation from './Reservation';
function App() {
  return (
    <div>
      <SignUp isLoggedIn={false}/>
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" /> */}
      <Reservation/>
        <Cform/>
        <CountApp/>
       <Employee/>
       <App5/>
       <App4/>
        <App2/>
        <Welcome fname="Swati" lname="Bhirud"/>
        <Welcome1 fname="Ashwin" lname="Patil"/>
        <Welcome1 />
        <App3/>
      
    </div>
  );
}

export default App;
