import React,{useState,useEffect} from 'react';

function App5(){
    const[count,setCount]=useState(0);

    useEffect(()=>{
        console.log(`you have clicked count ${count} times`);
    },[count]);
    const[count2,setCount2]=useState(0);

    useEffect(()=>{
        console.log(`you have clicked count2 ${count2} times`);
    },[count2]);
    return(
        <div>
            <button onClick={()=>setCount(count+1)}>Click Me</button>
            <button onClick={()=>setCount2(count2+1)}>Click Here</button>
        </div>
    )
}
export default App5;