import React,{Component} from 'react';

class Cform extends React.Component{
    constructor(){
        super();
        this.state={text:"",favColor:""};
        this.handleChange=this.handleChange.bind(this);
        this.onSubmitClick=this.onSubmitClick.bind(this);
        this.selectionChange=this.selectionChange.bind(this);
    }
    handleChange(event){
        this.setState({text:event.target.value});
    }
    selectionChange(event){
        this.setState({favColor:event.target.value});
    }
    onSubmitClick(event){
        alert("you have submitted name as :"+this.state.text+"and your favourite color is:"+this.state.favColor);
        event.preventDefault();
    }
    render(){
        return(
            <form onSubmit={this.onSubmitClick}>
                <lable>Name:</lable><input type="text" value={this.state.text} onChange={this.handleChange}/><br/>
                <label>Select Color: </label>
                <select value={this.state.favColor} onChange={this.selectionChange}>
                    <option value="Black">Black</option>
                    <option value="White">White</option>
                    <option value="Red">Red</option>
                    <option value="Green">Green</option>
                    <option value="Blue">Blue</option>
                </select>
                <input type="Submit" value="submit"/>
            </form>
        )
    }
}
export default Cform;