import React,{useState} from 'react';

function App4(){
    const [name,setName]=useState("ABC");
    const changeName=(e)=>{
        setName(e.target.value);
    };
    return(
        <div>
            <form>
            <p>My Name is {name}</p>
            Enter Name: <input type="text" value={name} onChange={changeName}/>
          
            </form>
        </div>
    )

}
export default App4;