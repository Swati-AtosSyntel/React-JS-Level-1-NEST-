import React,{Component} from 'react';

class UCform extends React.Component{
    constructor(props){
        super(props);
        this.onSubmitClick=this.onSubmitClick.bind(this);
        this.input=React.createRef();
    }
    onSubmitClick(event){
        alert("You have submitted name in the form as "+this.input.current.value);
        event.preventDefault();
    }
    render(){
        return(
            <form onSubmit={this.onSubmitClick}> 
                <h3>Uncontrolled Form</h3>
                <label>Name:</label> <input type="text" ref={this.input}/>
                <input type="submit" value="Submit"/>
            </form>
        );
    }
}
export default UCform;