import React,{Component} from 'react';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={data:[
            {id:123,name:"Swati"},
            {id:124,name:"Nilesh"},
            {id:125,name:"Nita"},
            {id:126,name:"Nisha"},
            {id:127,name:"Aakash"}
        ]};
    }
    render(){
        return(
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>name</th>
                </tr>
               {this.state.data.map((employee)=><TableRow emp={employee}/>)}
            </table>
        )
    }
}
export default Employee;
class TableRow extends React.Component{
    
    render(){
        return(
            <tr>
                <td>{this.props.emp.id}</td>
                <td>{this.props.emp.name}</td>
            </tr>
        
        )
    }
}