import React,{Component} from 'react';

class App2 extends React.Component{
    constructor(){
        super();
        this.state={fname:"Anushka", lname:"Sharma"}
    }
    render(){
        return(
            <div>
                <h3>{this.state.fname} {this.state.lname}</h3>
            </div>
        )
    }
}
export default App2;