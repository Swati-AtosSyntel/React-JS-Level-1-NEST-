import React,{Component} from 'react';
class App3 extends React.Component{
    constructor(){
        super();
        this.state={num:0};
        this.updateNumber=this.updateNumber.bind(this);
    }
    updateNumber(){
        this.setState({num:this.state.num+1});
    }
    render(){
        return(
            <div>
               <Child newNum={this.state.num}/>
                <button onClick={this.updateNumber}>Update Number</button>
            </div>
        )
    }
}
export default App3;
class Child extends React.Component{
    constructor(){
        super();
        console.log("Within constructor");
    }
    componentDidMount(){
        console.log("Component did mount");
    }
    componentWillReceiveProps(newProps){
        console.log("Component will receive props");
    }
    shouldComponentUpdate(nextPrpos,nextState){
        return false;
    }
    componentWillUpdate(nextProps,nextState){
        console.log("Component will Update")
    }
    render(){
        return(
            <div>
                <h3>{this.props.newNum}</h3>
            </div>
        )
    }
}